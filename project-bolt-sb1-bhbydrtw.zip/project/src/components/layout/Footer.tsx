import React from 'react';
import { Link } from 'react-router-dom';
import { Heart } from 'lucide-react';
import Logo from './Logo';

const Footer: React.FC = () => {
  return (
    <footer className="bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 py-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="md:col-span-1">
            <Link to="/" className="flex items-center gap-2">
              <Logo className="h-8 w-8" />
              <span className="text-xl font-bold text-primary-600 dark:text-primary-400">
                SureBrasil
              </span>
            </Link>
            <p className="mt-3 text-gray-600 dark:text-gray-300 text-sm">
              Encontre oportunidades de arbitragem esportiva em tempo real nas principais casas de apostas do Brasil.
            </p>
          </div>
          
          <div>
            <h3 className="text-gray-800 dark:text-gray-100 font-medium mb-3">Links</h3>
            <ul className="space-y-2">
              <li>
                <Link 
                  to="/surebets" 
                  className="text-gray-600 hover:text-primary-600 dark:text-gray-300 dark:hover:text-primary-400 transition-colors text-sm"
                >
                  Surebets
                </Link>
              </li>
              <li>
                <Link 
                  to="/premium" 
                  className="text-gray-600 hover:text-primary-600 dark:text-gray-300 dark:hover:text-primary-400 transition-colors text-sm"
                >
                  Premium
                </Link>
              </li>
              <li>
                <Link 
                  to="/dashboard" 
                  className="text-gray-600 hover:text-primary-600 dark:text-gray-300 dark:hover:text-primary-400 transition-colors text-sm"
                >
                  Dashboard
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-gray-800 dark:text-gray-100 font-medium mb-3">Suporte</h3>
            <ul className="space-y-2">
              <li>
                <Link 
                  to="/faq" 
                  className="text-gray-600 hover:text-primary-600 dark:text-gray-300 dark:hover:text-primary-400 transition-colors text-sm"
                >
                  FAQ
                </Link>
              </li>
              <li>
                <Link 
                  to="/contato" 
                  className="text-gray-600 hover:text-primary-600 dark:text-gray-300 dark:hover:text-primary-400 transition-colors text-sm"
                >
                  Contato
                </Link>
              </li>
              <li>
                <Link 
                  to="/termos" 
                  className="text-gray-600 hover:text-primary-600 dark:text-gray-300 dark:hover:text-primary-400 transition-colors text-sm"
                >
                  Termos de Uso
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-gray-800 dark:text-gray-100 font-medium mb-3">Legal</h3>
            <ul className="space-y-2">
              <li>
                <Link 
                  to="/privacidade" 
                  className="text-gray-600 hover:text-primary-600 dark:text-gray-300 dark:hover:text-primary-400 transition-colors text-sm"
                >
                  Política de Privacidade
                </Link>
              </li>
              <li>
                <Link 
                  to="/cookies" 
                  className="text-gray-600 hover:text-primary-600 dark:text-gray-300 dark:hover:text-primary-400 transition-colors text-sm"
                >
                  Política de Cookies
                </Link>
              </li>
              <li>
                <Link 
                  to="/responsibilidade" 
                  className="text-gray-600 hover:text-primary-600 dark:text-gray-300 dark:hover:text-primary-400 transition-colors text-sm"
                >
                  Jogo Responsável
                </Link>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-200 dark:border-gray-700 mt-8 pt-6 flex flex-col md:flex-row justify-between items-center">
          <p className="text-sm text-gray-600 dark:text-gray-400">
            &copy; {new Date().getFullYear()} SureBrasil. Todos os direitos reservados.
          </p>
          <p className="text-sm text-gray-600 dark:text-gray-400 flex items-center mt-2 md:mt-0">
            Feito com <Heart size={14} className="mx-1 text-error-500" /> no Brasil
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;