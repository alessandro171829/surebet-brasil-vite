import React from 'react';
import { BarChart3 } from 'lucide-react';

interface LogoProps {
  className?: string;
}

const Logo: React.FC<LogoProps> = ({ className = "h-6 w-6" }) => {
  return (
    <div className={`relative flex items-center justify-center rounded-lg bg-primary-600 text-white ${className}`}>
      <BarChart3 size={className === "h-6 w-6" ? 16 : 20} className="stroke-2" />
    </div>
  );
};

export default Logo;