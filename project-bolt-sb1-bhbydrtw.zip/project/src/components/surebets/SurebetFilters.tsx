import React, { useState } from 'react';
import { Filter, X } from 'lucide-react';
import { sports, marketTypes } from '../../api/surebetApi';

interface FiltersProps {
  onFilterChange: (filters: {
    sports: string[];
    marketTypes: string[];
    minProfit: number;
  }) => void;
  minProfit: number;
  selectedSports: string[];
  selectedMarketTypes: string[];
}

const SurebetFilters: React.FC<FiltersProps> = ({
  onFilterChange,
  minProfit,
  selectedSports,
  selectedMarketTypes
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [localMinProfit, setLocalMinProfit] = useState(minProfit);
  const [localSports, setLocalSports] = useState<string[]>(selectedSports);
  const [localMarketTypes, setLocalMarketTypes] = useState<string[]>(selectedMarketTypes);

  const toggleFilter = () => setIsOpen(!isOpen);

  const handleSportToggle = (sportId: string) => {
    if (localSports.includes(sportId)) {
      setLocalSports(localSports.filter(id => id !== sportId));
    } else {
      setLocalSports([...localSports, sportId]);
    }
  };

  const handleMarketToggle = (marketId: string) => {
    if (localMarketTypes.includes(marketId)) {
      setLocalMarketTypes(localMarketTypes.filter(id => id !== marketId));
    } else {
      setLocalMarketTypes([...localMarketTypes, marketId]);
    }
  };

  const handleMinProfitChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setLocalMinProfit(parseFloat(e.target.value));
  };

  const applyFilters = () => {
    onFilterChange({
      sports: localSports,
      marketTypes: localMarketTypes,
      minProfit: localMinProfit
    });
    setIsOpen(false);
  };

  const resetFilters = () => {
    setLocalSports([]);
    setLocalMarketTypes([]);
    setLocalMinProfit(0);
    onFilterChange({
      sports: [],
      marketTypes: [],
      minProfit: 0
    });
  };

  return (
    <div className="mb-6">
      <div className="flex justify-between items-center">
        <button
          onClick={toggleFilter}
          className="btn-outline text-sm flex items-center"
        >
          <Filter size={16} className="mr-2" />
          <span>Filtros</span>
          {(selectedSports.length > 0 || selectedMarketTypes.length > 0 || minProfit > 0) && (
            <span className="ml-2 bg-primary-500 text-white w-5 h-5 rounded-full flex items-center justify-center text-xs">
              {selectedSports.length + selectedMarketTypes.length + (minProfit > 0 ? 1 : 0)}
            </span>
          )}
        </button>
        
        {(selectedSports.length > 0 || selectedMarketTypes.length > 0 || minProfit > 0) && (
          <button
            onClick={resetFilters}
            className="text-sm text-gray-600 hover:text-primary-600 dark:text-gray-400 dark:hover:text-primary-400 flex items-center"
          >
            <X size={14} className="mr-1" />
            <span>Limpar filtros</span>
          </button>
        )}
      </div>
      
      {isOpen && (
        <div className="mt-4 p-4 bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 animate-fade-in">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <h3 className="text-sm font-medium mb-3 text-gray-700 dark:text-gray-300">Esportes</h3>
              <div className="space-y-2">
                {sports.map(sport => (
                  <label key={sport.id} className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={localSports.includes(sport.id)}
                      onChange={() => handleSportToggle(sport.id)}
                      className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                    />
                    <span className="text-gray-700 dark:text-gray-300">{sport.name}</span>
                  </label>
                ))}
              </div>
            </div>
            
            <div>
              <h3 className="text-sm font-medium mb-3 text-gray-700 dark:text-gray-300">Tipos de Mercado</h3>
              <div className="space-y-2">
                {marketTypes.map(market => (
                  <label key={market.id} className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={localMarketTypes.includes(market.id)}
                      onChange={() => handleMarketToggle(market.id)}
                      className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                    />
                    <span className="text-gray-700 dark:text-gray-300">{market.name}</span>
                  </label>
                ))}
              </div>
            </div>
            
            <div>
              <h3 className="text-sm font-medium mb-3 text-gray-700 dark:text-gray-300">Lucro Mínimo</h3>
              <input
                type="range"
                min="0"
                max="10"
                step="0.5"
                value={localMinProfit}
                onChange={handleMinProfitChange}
                className="w-full"
              />
              <div className="flex justify-between text-sm text-gray-600 dark:text-gray-400 mt-1">
                <span>0%</span>
                <span>{localMinProfit}%</span>
                <span>10%+</span>
              </div>
            </div>
          </div>
          
          <div className="mt-6 flex justify-end space-x-3">
            <button
              onClick={() => setIsOpen(false)}
              className="btn-outline text-sm"
            >
              Cancelar
            </button>
            <button
              onClick={applyFilters}
              className="btn-primary text-sm"
            >
              Aplicar Filtros
            </button>
          </div>
        </div>
      )}
      
      {/* Active filters display */}
      {(selectedSports.length > 0 || selectedMarketTypes.length > 0 || minProfit > 0) && (
        <div className="mt-4 flex flex-wrap gap-2">
          {selectedSports.map(sportId => {
            const sport = sports.find(s => s.id === sportId);
            return sport ? (
              <div key={sport.id} className="bg-gray-100 dark:bg-gray-700 px-2 py-1 text-xs rounded-full flex items-center">
                <span>{sport.name}</span>
                <button
                  onClick={() => {
                    const newSports = selectedSports.filter(id => id !== sportId);
                    onFilterChange({
                      sports: newSports,
                      marketTypes: selectedMarketTypes,
                      minProfit
                    });
                  }}
                  className="ml-1 text-gray-500 dark:text-gray-400 hover:text-error-500 dark:hover:text-error-400"
                >
                  <X size={12} />
                </button>
              </div>
            ) : null;
          })}
          
          {selectedMarketTypes.map(marketId => {
            const market = marketTypes.find(m => m.id === marketId);
            return market ? (
              <div key={market.id} className="bg-gray-100 dark:bg-gray-700 px-2 py-1 text-xs rounded-full flex items-center">
                <span>{market.name}</span>
                <button
                  onClick={() => {
                    const newMarkets = selectedMarketTypes.filter(id => id !== marketId);
                    onFilterChange({
                      sports: selectedSports,
                      marketTypes: newMarkets,
                      minProfit
                    });
                  }}
                  className="ml-1 text-gray-500 dark:text-gray-400 hover:text-error-500 dark:hover:text-error-400"
                >
                  <X size={12} />
                </button>
              </div>
            ) : null;
          })}
          
          {minProfit > 0 && (
            <div className="bg-gray-100 dark:bg-gray-700 px-2 py-1 text-xs rounded-full flex items-center">
              <span>Lucro mín: {minProfit}%</span>
              <button
                onClick={() => {
                  onFilterChange({
                    sports: selectedSports,
                    marketTypes: selectedMarketTypes,
                    minProfit: 0
                  });
                }}
                className="ml-1 text-gray-500 dark:text-gray-400 hover:text-error-500 dark:hover:text-error-400"
              >
                <X size={12} />
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default SurebetFilters;