import React, { useState, useEffect } from 'react';
import { Surebet, calculateOptimalStakes, getBookmakerById } from '../../api/surebetApi';

interface SurebetCalculatorProps {
  surebet: Surebet;
  initialBankroll: number;
}

const SurebetCalculator: React.FC<SurebetCalculatorProps> = ({ surebet, initialBankroll }) => {
  const [bankroll, setBankroll] = useState(initialBankroll);
  const [calculation, setCalculation] = useState(calculateOptimalStakes(surebet, initialBankroll));
  
  useEffect(() => {
    setCalculation(calculateOptimalStakes(surebet, bankroll));
  }, [bankroll, surebet]);
  
  const handleBankrollChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseFloat(e.target.value);
    if (!isNaN(value) && value > 0) {
      setBankroll(value);
    }
  };
  
  return (
    <div className="bg-gray-50 dark:bg-gray-900 rounded-lg p-4 border border-gray-200 dark:border-gray-700">
      <h3 className="text-lg font-semibold mb-4">Calculadora de Apostas</h3>
      
      <div className="mb-4">
        <label htmlFor="bankroll" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
          Banca disponível (R$)
        </label>
        <input
          type="number"
          id="bankroll"
          value={bankroll}
          onChange={handleBankrollChange}
          className="input"
          min={1}
          step={100}
        />
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-4">
        <div className="bg-white dark:bg-gray-800 p-3 rounded-lg border border-gray-200 dark:border-gray-700">
          <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
            Distribuição de Apostas
          </h4>
          
          <div className="space-y-3">
            {calculation.stakes.map((stake, index) => {
              const outcome = surebet.outcomes.find(o => o.id === stake.outcomeId);
              const bookmaker = outcome ? getBookmakerById(outcome.bookmakerId) : undefined;
              
              if (!outcome || !bookmaker) return null;
              
              return (
                <div key={stake.outcomeId} className="flex items-center justify-between">
                  <div className="flex items-center">
                    <img 
                      src={bookmaker.logo} 
                      alt={bookmaker.name} 
                      className="w-12 h-5 object-contain mr-2" 
                    />
                    <span className="text-sm font-medium">
                      {outcome.name} ({outcome.odds.toFixed(2)})
                    </span>
                  </div>
                  <div className="font-semibold">
                    R$ {stake.amount.toFixed(2)}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
        
        <div className="bg-white dark:bg-gray-800 p-3 rounded-lg border border-gray-200 dark:border-gray-700">
          <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
            Resumo
          </h4>
          
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-sm text-gray-600 dark:text-gray-400">Total apostado</span>
              <span className="font-medium">R$ {calculation.totalStake.toFixed(2)}</span>
            </div>
            
            <div className="flex justify-between">
              <span className="text-sm text-gray-600 dark:text-gray-400">Lucro garantido (%)</span>
              <span className="font-medium text-success-600 dark:text-success-400">
                {calculation.profitPercentage.toFixed(2)}%
              </span>
            </div>
            
            <div className="flex justify-between border-t border-gray-200 dark:border-gray-700 pt-2 mt-2">
              <span className="text-sm font-medium">Lucro garantido (R$)</span>
              <span className="font-bold text-success-600 dark:text-success-400">
                R$ {calculation.guaranteedProfit.toFixed(2)}
              </span>
            </div>
          </div>
        </div>
      </div>
      
      <div className="bg-primary-50 dark:bg-primary-900/30 p-3 rounded-lg text-sm">
        <p className="text-primary-800 dark:text-primary-300">
          <strong>Como funciona:</strong> Aposte o valor exato em cada casa de apostas para garantir lucro independente do resultado. 
          As apostas já estão otimizadas para maximizar seu lucro.
        </p>
      </div>
    </div>
  );
};

export default SurebetCalculator;