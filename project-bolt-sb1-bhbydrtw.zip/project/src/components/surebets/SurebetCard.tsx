import React, { useState } from 'react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Calculator, Clock, Star, Tally1 as Ball, ChevronDown, ChevronUp, ExternalLink } from 'lucide-react';

import { 
  Surebet, 
  Outcome, 
  getBookmakerById, 
  calculateOptimalStakes, 
  StakeCalculation 
} from '../../api/surebetApi';
import { useUser } from '../../contexts/UserContext';
import SurebetCalculator from './SurebetCalculator';

interface SurebetCardProps {
  surebet: Surebet;
}

const SurebetCard: React.FC<SurebetCardProps> = ({ surebet }) => {
  const [expanded, setExpanded] = useState(false);
  const [showCalculator, setShowCalculator] = useState(false);
  const { settings } = useUser();
  
  const toggleExpanded = () => {
    setExpanded(!expanded);
  };
  
  const toggleCalculator = () => {
    setShowCalculator(!showCalculator);
    if (!expanded) {
      setExpanded(true);
    }
  };
  
  // Calculate stakes based on user's bankroll
  const calculation = calculateOptimalStakes(surebet, settings.bankroll);
  
  const formattedDate = format(
    new Date(surebet.startTime), 
    "dd 'de' MMMM, HH:mm", 
    { locale: ptBR }
  );
  
  const SportIcon = () => {
    if (surebet.sportId === 'football') {
      return <Ball size={18} className="text-primary-500" />;
    } else if (surebet.sportId === 'tennis') {
      return <Ball size={18} className="text-success-500" />;
    } else if (surebet.sportId === 'basketball') {
      return <Ball size={18} className="text-warning-500" />;
    } else {
      return <Ball size={18} />;
    }
  };
  
  return (
    <div className="surebet-card hover:border-primary-300 dark:hover:border-primary-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-1">
            <SportIcon />
            <span className="text-sm text-gray-600 dark:text-gray-400">
              {surebet.sportName}
            </span>
            <span className="text-xs px-2 py-0.5 bg-primary-100 dark:bg-primary-900 text-primary-800 dark:text-primary-300 rounded-full">
              {surebet.market.name}
            </span>
          </div>
          
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-1">
            {surebet.eventName}
          </h3>
          
          <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
            <Clock size={14} />
            <span>{formattedDate}</span>
          </div>
        </div>
        
        <div className="flex flex-col items-end mt-4 md:mt-0">
          <div className="bg-success-50 dark:bg-success-900/30 px-3 py-1.5 rounded-lg">
            <span className="text-success-700 dark:text-success-400 font-medium text-sm">
              Lucro garantido
            </span>
            <div className="text-lg font-bold text-success-700 dark:text-success-400">
              +{surebet.profit.toFixed(2)}%
            </div>
          </div>
          
          <div className="flex mt-3 gap-2">
            <button 
              className="btn-outline text-sm"
              onClick={toggleCalculator}
            >
              <Calculator size={16} className="mr-1" />
              <span className="hidden sm:inline">Calcular</span>
            </button>
            
            <button
              onClick={toggleExpanded}
              className="btn-outline text-sm"
            >
              {expanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
              <span className="ml-1 hidden sm:inline">{expanded ? 'Recolher' : 'Detalhes'}</span>
            </button>
          </div>
        </div>
      </div>
      
      {expanded && (
        <div className="mt-4 animate-slide-up">
          <div className="grid grid-cols-1 gap-3">
            {surebet.outcomes.map((outcome) => {
              const bookmaker = getBookmakerById(outcome.bookmakerId);
              const stake = calculation.stakes.find(s => s.outcomeId === outcome.id);
              
              return (
                <div 
                  key={outcome.id} 
                  className="bg-white dark:bg-gray-800 p-4 rounded-lg border border-gray-200 dark:border-gray-700 hover:border-primary-300 dark:hover:border-primary-600 transition-colors"
                >
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="font-medium text-gray-900 dark:text-white">
                      {bookmaker?.name}
                    </h4>
                    <a 
                      href={bookmaker?.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-primary-600 hover:text-primary-700 dark:text-primary-400 dark:hover:text-primary-300 flex items-center gap-1 text-sm"
                    >
                      <span>Abrir site</span>
                      <ExternalLink size={14} />
                    </a>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <div>
                      <div className="text-sm text-gray-600 dark:text-gray-400 mb-1">
                        Aposta: {outcome.name}
                      </div>
                      <div className="text-2xl font-bold text-primary-600 dark:text-primary-400">
                        {outcome.odds.toFixed(2)}
                      </div>
                    </div>
                    
                    {stake && (
                      <div className="text-right">
                        <div className="text-sm text-gray-600 dark:text-gray-400 mb-1">
                          Valor sugerido
                        </div>
                        <div className="text-lg font-semibold">
                          R$ {stake.amount.toFixed(2)}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
          
          {showCalculator && (
            <div className="mt-4">
              <SurebetCalculator 
                surebet={surebet} 
                initialBankroll={settings.bankroll}
              />
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default SurebetCard;