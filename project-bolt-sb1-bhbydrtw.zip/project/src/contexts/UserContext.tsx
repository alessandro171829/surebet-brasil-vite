import React, { createContext, useState, useContext, useEffect } from 'react';
import { useAuth } from './AuthContext';

interface UserSettings {
  bankroll: number;
  notificationsEnabled: boolean;
  profitThreshold: number;
  favoriteSports: string[];
}

interface UserContextType {
  settings: UserSettings;
  updateSettings: (newSettings: Partial<UserSettings>) => void;
  bettingHistory: BetRecord[];
  addBetRecord: (record: BetRecord) => void;
}

export interface BetRecord {
  id: string;
  date: Date;
  event: string;
  bookmakers: { name: string; stake: number; odds: number }[];
  profit: number;
  status: 'pending' | 'completed' | 'canceled';
}

const defaultSettings: UserSettings = {
  bankroll: 1000,
  notificationsEnabled: true,
  profitThreshold: 5, // minimum profit % to show
  favoriteSports: ['football', 'tennis', 'basketball'],
};

const UserContext = createContext<UserContextType | undefined>(undefined);

export const UserProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const [settings, setSettings] = useState<UserSettings>(defaultSettings);
  const [bettingHistory, setBettingHistory] = useState<BetRecord[]>([]);

  useEffect(() => {
    if (user) {
      // In a real app, this would fetch from an API
      const storedSettings = localStorage.getItem(`settings_${user.id}`);
      const storedHistory = localStorage.getItem(`history_${user.id}`);
      
      if (storedSettings) {
        setSettings(JSON.parse(storedSettings));
      }
      
      if (storedHistory) {
        setBettingHistory(JSON.parse(storedHistory));
      }
    }
  }, [user]);

  const updateSettings = (newSettings: Partial<UserSettings>) => {
    if (!user) return;
    
    const updatedSettings = { ...settings, ...newSettings };
    setSettings(updatedSettings);
    localStorage.setItem(`settings_${user.id}`, JSON.stringify(updatedSettings));
  };

  const addBetRecord = (record: BetRecord) => {
    if (!user) return;
    
    const newHistory = [record, ...bettingHistory];
    setBettingHistory(newHistory);
    localStorage.setItem(`history_${user.id}`, JSON.stringify(newHistory));
  };

  return (
    <UserContext.Provider value={{ settings, updateSettings, bettingHistory, addBetRecord }}>
      {children}
    </UserContext.Provider>
  );
};

export const useUser = (): UserContextType => {
  const context = useContext(UserContext);
  if (context === undefined) {
    throw new Error('useUser must be used within a UserProvider');
  }
  return context;
};