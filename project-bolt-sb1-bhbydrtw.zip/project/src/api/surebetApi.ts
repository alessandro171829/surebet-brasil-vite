import { format } from 'date-fns';

export interface Bookmaker {
  id: string;
  name: string;
  logo: string;
  url: string;
}

export interface Market {
  id: string;
  name: string;
  description: string;
}

export interface Outcome {
  id: string;
  name: string;
  odds: number;
  bookmakerId: string;
}

export interface Surebet {
  id: string;
  eventId: string;
  eventName: string;
  sportId: string;
  sportName: string;
  startTime: Date;
  market: Market;
  outcomes: Outcome[];
  profit: number;
}

// Updated bookmakers data with official URLs
export const bookmakers: Bookmaker[] = [
  { 
    id: 'betano', 
    name: 'Betano', 
    logo: 'https://upload.wikimedia.org/wikipedia/commons/8/8f/Betano_logo.png',
    url: 'https://br.betano.com'
  },
  { 
    id: 'bet365', 
    name: 'Bet365', 
    logo: 'https://upload.wikimedia.org/wikipedia/commons/8/80/Bet365_logo.svg',
    url: 'https://www.bet365.com/br'
  },
  { 
    id: 'sportingbet', 
    name: 'Sportingbet', 
    logo: 'https://upload.wikimedia.org/wikipedia/commons/7/78/Sportingbet_logo.svg',
    url: 'https://www.sportingbet.com/br'
  },
  { 
    id: 'pixbet', 
    name: 'Pixbet', 
    logo: 'https://www.pixbet.com/images/logo-light.png',
    url: 'https://www.pixbet.com'
  },
  { 
    id: 'kto', 
    name: 'KTO', 
    logo: 'https://www.kto.com/images/kto-logo.png',
    url: 'https://www.kto.com'
  },
  { 
    id: 'galerabet', 
    name: 'Galera.bet', 
    logo: 'https://www.galerabet.com/images/logo.png',
    url: 'https://www.galerabet.com'
  },
  { 
    id: 'betsson', 
    name: 'Betsson', 
    logo: 'https://upload.wikimedia.org/wikipedia/commons/3/3b/Betsson_logo.svg',
    url: 'https://www.betsson.com/br'
  },
  { 
    id: 'parimatch', 
    name: 'Parimatch', 
    logo: 'https://upload.wikimedia.org/wikipedia/commons/d/d6/Parimatch_logo.svg',
    url: 'https://br.parimatch.com'
  },
  {
    id: 'pinnacle',
    name: 'Pinnacle',
    logo: 'https://www.pinnacle.com/favicon.ico',
    url: 'https://www.pinnacle.com/pt'
  },
  {
    id: 'rivalo',
    name: 'Rivalo',
    logo: 'https://www.rivalo.com/favicon.ico',
    url: 'https://www.rivalo.com/br'
  },
  {
    id: 'betway',
    name: 'Betway',
    logo: 'https://www.betway.com/favicon.ico',
    url: 'https://betway.com/pt/sports'
  },
  {
    id: '22bet',
    name: '22Bet',
    logo: 'https://22bet.com/favicon.ico',
    url: 'https://22bet.com/pt'
  }
];

// Mock sports data
export const sports = [
  { id: 'football', name: 'Futebol' },
  { id: 'tennis', name: 'Tênis' },
  { id: 'basketball', name: 'Basquete' },
  { id: 'volleyball', name: 'Vôlei' },
  { id: 'mma', name: 'MMA' },
];

// Mock market types
export const marketTypes = [
  { id: '1x2', name: 'Resultado Final (1X2)' },
  { id: 'over_under', name: 'Mais/Menos (Over/Under)' },
  { id: 'btts', name: 'Ambas Marcam (Sim/Não)' },
  { id: 'dnb', name: 'Draw No Bet' },
  { id: 'handicap', name: 'Handicap' },
];

// Generate random future date within the next 7 days
const randomFutureDate = () => {
  const now = new Date();
  const daysToAdd = Math.floor(Math.random() * 7) + 1;
  const hoursToAdd = Math.floor(Math.random() * 24);
  const minutesToAdd = Math.floor(Math.random() * 60);
  
  now.setDate(now.getDate() + daysToAdd);
  now.setHours(now.getHours() + hoursToAdd);
  now.setMinutes(now.getMinutes() + minutesToAdd);
  
  return now;
};

// Generate random events
const generateEvents = () => {
  const footballTeams = [
    'Flamengo', 'Corinthians', 'São Paulo', 'Palmeiras', 
    'Santos', 'Grêmio', 'Internacional', 'Atlético Mineiro',
    'Fluminense', 'Vasco', 'Botafogo', 'Cruzeiro'
  ];
  
  const tennisPlayers = [
    'Alcaraz', 'Djokovic', 'Nadal', 'Medvedev', 
    'Zverev', 'Thiem', 'Tsitsipas', 'Ruud',
    'Sinner', 'Fritz', 'Hurkacz', 'Rublev'
  ];
  
  const basketballTeams = [
    'Flamengo', 'Franca', 'Pinheiros', 'Minas',
    'Paulistano', 'Bauru', 'Unifacisa', 'São José'
  ];
  
  const events = [];
  
  // Football events
  for (let i = 0; i < 8; i++) {
    const homeIdx = Math.floor(Math.random() * footballTeams.length);
    let awayIdx = Math.floor(Math.random() * footballTeams.length);
    while (awayIdx === homeIdx) {
      awayIdx = Math.floor(Math.random() * footballTeams.length);
    }
    
    events.push({
      id: `football_${i}`,
      name: `${footballTeams[homeIdx]} vs ${footballTeams[awayIdx]}`,
      sportId: 'football',
      startTime: randomFutureDate()
    });
  }
  
  // Tennis events
  for (let i = 0; i < 6; i++) {
    const homeIdx = Math.floor(Math.random() * tennisPlayers.length);
    let awayIdx = Math.floor(Math.random() * tennisPlayers.length);
    while (awayIdx === homeIdx) {
      awayIdx = Math.floor(Math.random() * tennisPlayers.length);
    }
    
    events.push({
      id: `tennis_${i}`,
      name: `${tennisPlayers[homeIdx]} vs ${tennisPlayers[awayIdx]}`,
      sportId: 'tennis',
      startTime: randomFutureDate()
    });
  }
  
  // Basketball events
  for (let i = 0; i < 4; i++) {
    const homeIdx = Math.floor(Math.random() * basketballTeams.length);
    let awayIdx = Math.floor(Math.random() * basketballTeams.length);
    while (awayIdx === homeIdx) {
      awayIdx = Math.floor(Math.random() * basketballTeams.length);
    }
    
    events.push({
      id: `basketball_${i}`,
      name: `${basketballTeams[homeIdx]} vs ${basketballTeams[awayIdx]}`,
      sportId: 'basketball',
      startTime: randomFutureDate()
    });
  }
  
  return events;
};

// Generate mock surebets with higher profit margins
const generateSurebets = (count = 15) => {
  const events = generateEvents();
  const surebets: Surebet[] = [];
  
  for (let i = 0; i < count; i++) {
    const eventIndex = Math.floor(Math.random() * events.length);
    const event = events[eventIndex];
    
    // Randomly select market
    const marketIndex = Math.floor(Math.random() * marketTypes.length);
    const market = marketTypes[marketIndex];
    
    // Generate outcomes based on market type
    let outcomes: Outcome[] = [];
    
    if (market.id === '1x2') {
      // 1X2 market has 3 outcomes (home, draw, away)
      const shuffledBookmakers = [...bookmakers].sort(() => 0.5 - Math.random()).slice(0, 3);
      
      // Generate odds that create a surebet (sum of inverses < 1)
      // For a 4-8% profit opportunity
      const profitFactor = 0.92 - (Math.random() * 0.04); // 0.88 to 0.92
      
      let homeOdds = 2.0 + Math.random() * 1.5; // 2.0 to 3.5
      let drawOdds = 3.0 + Math.random() * 1.5; // 3.0 to 4.5
      let awayOdds = 2.0 + Math.random() * 2.0; // 2.0 to 4.0
      
      // Adjust to create a surebet
      const sumInv = (1/homeOdds) + (1/drawOdds) + (1/awayOdds);
      const adjustFactor = sumInv / profitFactor;
      
      homeOdds *= adjustFactor;
      drawOdds *= adjustFactor;
      awayOdds *= adjustFactor;
      
      // Calculate profit percentage
      const profit = (1 - ((1/homeOdds) + (1/drawOdds) + (1/awayOdds))) * 100;
      
      outcomes = [
        {
          id: `${event.id}_home`,
          name: 'Casa',
          odds: parseFloat(homeOdds.toFixed(2)),
          bookmakerId: shuffledBookmakers[0].id
        },
        {
          id: `${event.id}_draw`,
          name: 'Empate',
          odds: parseFloat(drawOdds.toFixed(2)),
          bookmakerId: shuffledBookmakers[1].id
        },
        {
          id: `${event.id}_away`,
          name: 'Fora',
          odds: parseFloat(awayOdds.toFixed(2)),
          bookmakerId: shuffledBookmakers[2].id
        }
      ];
      
      surebets.push({
        id: `surebet_${i}`,
        eventId: event.id,
        eventName: event.name,
        sportId: event.sportId,
        sportName: sports.find(s => s.id === event.sportId)?.name || '',
        startTime: event.startTime,
        market: {
          id: market.id,
          name: market.name,
          description: 'Aposte no resultado final da partida'
        },
        outcomes,
        profit: parseFloat(profit.toFixed(2))
      });
    } else if (market.id === 'over_under') {
      // Over/Under market with 2 outcomes
      const shuffledBookmakers = [...bookmakers].sort(() => 0.5 - Math.random()).slice(0, 2);
      
      // Generate odds that create a surebet with higher profit
      const profitFactor = 0.92 - (Math.random() * 0.04); // 0.88 to 0.92
      
      let overOdds = 1.8 + Math.random() * 0.8; // 1.8 to 2.6
      let underOdds = 1.8 + Math.random() * 0.8; // 1.8 to 2.6
      
      // Adjust to create a surebet
      const sumInv = (1/overOdds) + (1/underOdds);
      const adjustFactor = sumInv / profitFactor;
      
      overOdds *= adjustFactor;
      underOdds *= adjustFactor;
      
      // Calculate profit percentage
      const profit = (1 - ((1/overOdds) + (1/underOdds))) * 100;
      
      // Random threshold for over/under
      const threshold = event.sportId === 'football' 
        ? (Math.floor(Math.random() * 4) + 1.5).toFixed(1) 
        : event.sportId === 'basketball'
          ? (Math.floor(Math.random() * 20) + 160).toFixed(1)
          : (Math.floor(Math.random() * 5) + 20).toFixed(1);
      
      outcomes = [
        {
          id: `${event.id}_over`,
          name: `Mais de ${threshold}`,
          odds: parseFloat(overOdds.toFixed(2)),
          bookmakerId: shuffledBookmakers[0].id
        },
        {
          id: `${event.id}_under`,
          name: `Menos de ${threshold}`,
          odds: parseFloat(underOdds.toFixed(2)),
          bookmakerId: shuffledBookmakers[1].id
        }
      ];
      
      surebets.push({
        id: `surebet_${i}`,
        eventId: event.id,
        eventName: event.name,
        sportId: event.sportId,
        sportName: sports.find(s => s.id === event.sportId)?.name || '',
        startTime: event.startTime,
        market: {
          id: market.id,
          name: market.name,
          description: `Número total de ${event.sportId === 'football' ? 'gols' : 'pontos'}`
        },
        outcomes,
        profit: parseFloat(profit.toFixed(2))
      });
    }
  }
  
  // Sort by profit (highest first)
  return surebets.sort((a, b) => b.profit - a.profit);
};

let freeSurebetsShown = 0;

// Mock API functions
export const fetchSurebets = async (
  filters: {
    sports?: string[];
    marketTypes?: string[];
    minProfit?: number;
  } = {}
): Promise<Surebet[]> => {
  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 800));
  
  // Generate mock data
  let surebets = generateSurebets(15);
  
  // Apply filters
  if (filters.sports && filters.sports.length > 0) {
    surebets = surebets.filter(sb => filters.sports!.includes(sb.sportId));
  }
  
  if (filters.marketTypes && filters.marketTypes.length > 0) {
    surebets = surebets.filter(sb => filters.marketTypes!.includes(sb.market.id));
  }
  
  if (filters.minProfit) {
    surebets = surebets.filter(sb => sb.profit >= filters.minProfit);
  }
  
  // For free users, only show 2 surebets
  const user = JSON.parse(localStorage.getItem('user') || '{}');
  if (!user?.isPremium) {
    if (freeSurebetsShown >= 2) {
      return [];
    }
    freeSurebetsShown += 1;
    return surebets.slice(0, 1);
  }
  
  return surebets;
};

export const getBookmakerById = (id: string): Bookmaker | undefined => {
  return bookmakers.find(b => b.id === id);
};

// Calculate optimal stakes for each outcome to guarantee profit
export interface StakeCalculation {
  totalStake: number;
  stakes: { outcomeId: string, amount: number }[];
  guaranteedProfit: number;
  profitPercentage: number;
}

export const calculateOptimalStakes = (
  surebet: Surebet, 
  totalBankroll: number
): StakeCalculation => {
  const outcomes = surebet.outcomes;
  
  // Calculate sum of inverse odds
  const sumInverseOdds = outcomes.reduce((sum, outcome) => sum + (1 / outcome.odds), 0);
  
  // Calculate profit percentage
  const profitPercentage = (1 - sumInverseOdds) * 100;
  
  // Calculate stake for each outcome
  const stakes = outcomes.map(outcome => {
    // Formula: stake proportion = (1/odds) / sum(1/odds)
    const stakeProportion = (1 / outcome.odds) / sumInverseOdds;
    const amount = totalBankroll * stakeProportion;
    
    return {
      outcomeId: outcome.id,
      amount: parseFloat(amount.toFixed(2))
    };
  });
  
  // Calculate guaranteed profit
  const guaranteedProfit = totalBankroll * (1 - sumInverseOdds);
  
  return {
    totalStake: totalBankroll,
    stakes,
    guaranteedProfit: parseFloat(guaranteedProfit.toFixed(2)),
    profitPercentage: parseFloat(profitPercentage.toFixed(2))
  };
};