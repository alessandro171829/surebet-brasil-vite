import React, { useState, useEffect } from 'react';
import { RefreshCw, AlertTriangle, Info, Lock } from 'lucide-react';
import { toast } from 'react-toastify';
import { fetchSurebets, Surebet } from '../api/surebetApi';
import { useAuth } from '../contexts/AuthContext';
import { useUser } from '../contexts/UserContext';
import SurebetCard from '../components/surebets/SurebetCard';
import SurebetFilters from '../components/surebets/SurebetFilters';

const Surebets: React.FC = () => {
  const { isAuthenticated, user } = useAuth();
  const { settings } = useUser();
  const [surebets, setSurebets] = useState<Surebet[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date());
  const [refreshing, setRefreshing] = useState(false);
  
  // Filters
  const [selectedSports, setSelectedSports] = useState<string[]>([]);
  const [selectedMarketTypes, setSelectedMarketTypes] = useState<string[]>([]);
  const [minProfit, setMinProfit] = useState<number>(0);
  
  const loadSurebets = async () => {
    try {
      setError(null);
      
      if (refreshing) {
        return;
      }
      
      setRefreshing(true);
      
      const data = await fetchSurebets({
        sports: selectedSports.length > 0 ? selectedSports : undefined,
        marketTypes: selectedMarketTypes.length > 0 ? selectedMarketTypes : undefined,
        minProfit: minProfit > 0 ? minProfit : undefined,
      });
      
      setSurebets(data);
      setLastUpdated(new Date());
      
    } catch (err) {
      console.error(err);
      setError('Falha ao carregar oportunidades. Tente novamente.');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };
  
  useEffect(() => {
    loadSurebets();
    
    // Set up auto-refresh every 60 seconds
    const intervalId = setInterval(() => {
      loadSurebets();
    }, 60000);
    
    return () => {
      clearInterval(intervalId);
    };
  }, [selectedSports, selectedMarketTypes, minProfit]);
  
  const handleRefresh = () => {
    loadSurebets();
    toast.info('Buscando novas oportunidades...');
  };
  
  const handleFilterChange = (filters: { sports: string[]; marketTypes: string[]; minProfit: number }) => {
    setSelectedSports(filters.sports);
    setSelectedMarketTypes(filters.marketTypes);
    setMinProfit(filters.minProfit);
  };
  
  if (!isAuthenticated) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-bold mb-4">Acesso Restrito</h2>
        <p className="text-gray-600 dark:text-gray-400 mb-6">
          Você precisa estar logado para acessar as surebets.
        </p>
        <a href="/register" className="btn-primary">
          Criar Conta Grátis
        </a>
      </div>
    );
  }
  
  return (
    <div>
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold mb-2">Surebets em Tempo Real</h1>
          <p className="text-gray-600 dark:text-gray-400">
            Encontre oportunidades de arbitragem com lucro garantido
          </p>
        </div>
        
        <button
          onClick={handleRefresh}
          disabled={refreshing}
          className="btn-outline mt-4 md:mt-0 flex items-center"
        >
          <RefreshCw size={16} className={`mr-2 ${refreshing ? 'animate-spin' : ''}`} />
          <span>{refreshing ? 'Atualizando...' : 'Atualizar'}</span>
        </button>
      </div>
      
      {!user?.isPremium && (
        <div className="bg-primary-50 dark:bg-primary-900/20 p-4 rounded-lg mb-6 flex items-center justify-between">
          <div className="flex items-center">
            <Lock size={20} className="text-primary-600 dark:text-primary-400 mr-2" />
            <p className="text-primary-800 dark:text-primary-200">
              <span className="font-medium">Plano Gratuito:</span> Você tem acesso a 2 surebets. Faça upgrade para o plano premium para acesso ilimitado.
            </p>
          </div>
          <Link to="/premium" className="btn-primary text-sm whitespace-nowrap">
            Obter Premium
          </Link>
        </div>
      )}
      
      <SurebetFilters
        onFilterChange={handleFilterChange}
        minProfit={minProfit}
        selectedSports={selectedSports}
        selectedMarketTypes={selectedMarketTypes}
      />
      
      {loading ? (
        <div className="flex flex-col items-center justify-center py-20">
          <div className="w-12 h-12 border-4 border-primary-500 border-t-transparent rounded-full animate-spin mb-4"></div>
          <p className="text-gray-600 dark:text-gray-400">Buscando oportunidades...</p>
        </div>
      ) : error ? (
        <div className="bg-error-50 dark:bg-error-900/30 rounded-lg p-6 text-center">
          <AlertTriangle size={32} className="mx-auto text-error-500 mb-2" />
          <p className="text-error-800 dark:text-error-300">{error}</p>
          <button 
            onClick={handleRefresh}
            className="btn-outline mt-4"
          >
            Tentar Novamente
          </button>
        </div>
      ) : (
        <>
          <div className="flex items-center justify-between mb-4 text-sm text-gray-600 dark:text-gray-400">
            <div>
              Última atualização: {lastUpdated.toLocaleTimeString()}
            </div>
            <div>
              {surebets.length} oportunidades encontradas
            </div>
          </div>
          
          {surebets.length > 0 ? (
            <div className="space-y-4">
              {surebets.map((surebet) => (
                <SurebetCard key={surebet.id} surebet={surebet} />
              ))}
              
              {!user?.isPremium && (
                <div className="bg-primary-50 dark:bg-primary-900/20 p-6 rounded-lg text-center">
                  <Lock size={32} className="mx-auto text-primary-600 dark:text-primary-400 mb-4" />
                  <h3 className="text-xl font-semibold mb-2">
                    Desbloqueie Acesso Ilimitado
                  </h3>
                  <p className="text-gray-600 dark:text-gray-400 mb-4">
                    Upgrade para o plano premium para ver todas as oportunidades de arbitragem disponíveis.
                  </p>
                  <Link to="/premium" className="btn-primary">
                    Obter Acesso Premium
                  </Link>
                </div>
              )}
            </div>
          ) : (
            <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-8 text-center">
              <Info size={32} className="mx-auto text-gray-400 mb-2" />
              <h3 className="text-lg font-semibold mb-2">Nenhuma oportunidade encontrada</h3>
              <p className="text-gray-600 dark:text-gray-400 mb-4">
                {!user?.isPremium && freeSurebetsShown >= 2 ? (
                  <>
                    Você atingiu o limite de surebets gratuitas. Faça upgrade para o plano premium para continuar.
                    <br />
                    <Link to="/premium" className="btn-primary mt-4 inline-block">
                      Obter Premium
                    </Link>
                  </>
                ) : (
                  <>
                    Não foram encontradas surebets com os filtros atuais. Tente modificar os filtros ou atualizar a página.
                    <br />
                    <button 
                      onClick={handleRefresh}
                      className="btn-outline mt-4"
                    >
                      Atualizar Oportunidades
                    </button>
                  </>
                )}
              </p>
            </div>
          )}
        </>
      )}
    </div>
  );
};

export default Surebets;