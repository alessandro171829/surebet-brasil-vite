import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Wallet, BarChart3, ArrowUpRight, ArrowDownRight, BarChart, Clock } from 'lucide-react';
import { format } from 'date-fns';
import { useUser, BetRecord } from '../contexts/UserContext';

const Dashboard: React.FC = () => {
  const { settings, bettingHistory, updateSettings } = useUser();
  const [bankroll, setBankroll] = useState(settings.bankroll);
  
  const handleBankrollUpdate = () => {
    updateSettings({ bankroll });
  };
  
  // Calculate dashboard stats
  const totalBets = bettingHistory.length;
  const completedBets = bettingHistory.filter(bet => bet.status === 'completed').length;
  const totalProfit = bettingHistory.reduce((total, bet) => total + bet.profit, 0);
  const profitPercentage = settings.bankroll > 0 
    ? (totalProfit / settings.bankroll) * 100 
    : 0;
  
  return (
    <div>
      <h1 className="text-2xl md:text-3xl font-bold mb-6">Dashboard</h1>
      
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="card p-6">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">Banca Atual</p>
              <h3 className="text-2xl font-bold">R$ {settings.bankroll.toFixed(2)}</h3>
            </div>
            <div className="p-3 bg-primary-100 dark:bg-primary-900/30 rounded-lg">
              <Wallet size={24} className="text-primary-600 dark:text-primary-400" />
            </div>
          </div>
          
          <div className="mt-4">
            <div className="flex items-center">
              <div className="flex-1">
                <label htmlFor="bankroll" className="text-sm text-gray-600 dark:text-gray-400 mb-1 block">
                  Atualizar banca
                </label>
                <div className="flex gap-2">
                  <input
                    type="number"
                    id="bankroll"
                    value={bankroll}
                    onChange={(e) => setBankroll(parseFloat(e.target.value))}
                    className="input"
                  />
                  <button 
                    onClick={handleBankrollUpdate}
                    className="btn-primary text-sm px-3"
                  >
                    Salvar
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="card p-6">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">Lucro Total</p>
              <h3 className={`text-2xl font-bold ${totalProfit >= 0 ? 'text-success-600 dark:text-success-400' : 'text-error-600 dark:text-error-400'}`}>
                R$ {totalProfit.toFixed(2)}
              </h3>
            </div>
            <div className="p-3 bg-success-100 dark:bg-success-900/30 rounded-lg">
              <BarChart3 size={24} className="text-success-600 dark:text-success-400" />
            </div>
          </div>
          
          <div className="mt-4 flex items-center">
            {profitPercentage !== 0 && (
              <>
                {profitPercentage > 0 ? (
                  <ArrowUpRight size={16} className="text-success-500 mr-1" />
                ) : (
                  <ArrowDownRight size={16} className="text-error-500 mr-1" />
                )}
              </>
            )}
            <span className={`text-sm ${profitPercentage > 0 ? 'text-success-600 dark:text-success-400' : profitPercentage < 0 ? 'text-error-600 dark:text-error-400' : 'text-gray-600 dark:text-gray-400'}`}>
              {Math.abs(profitPercentage).toFixed(2)}% da banca
            </span>
          </div>
        </div>
        
        <div className="card p-6">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">Apostas Realizadas</p>
              <h3 className="text-2xl font-bold">{totalBets}</h3>
            </div>
            <div className="p-3 bg-primary-100 dark:bg-primary-900/30 rounded-lg">
              <BarChart size={24} className="text-primary-600 dark:text-primary-400" />
            </div>
          </div>
          
          <div className="mt-4">
            <span className="text-sm text-gray-600 dark:text-gray-400">
              {completedBets} apostas concluídas
            </span>
          </div>
        </div>
      </div>
      
      {/* Betting History */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold">Histórico de Apostas</h2>
          <Link to="/surebets" className="text-primary-600 dark:text-primary-400 text-sm hover:underline">
            Encontrar novas oportunidades
          </Link>
        </div>
        
        {bettingHistory.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-gray-50 dark:bg-gray-800 text-left">
                  <th className="px-4 py-3 text-sm font-medium text-gray-600 dark:text-gray-300">Data</th>
                  <th className="px-4 py-3 text-sm font-medium text-gray-600 dark:text-gray-300">Evento</th>
                  <th className="px-4 py-3 text-sm font-medium text-gray-600 dark:text-gray-300">Casas de Apostas</th>
                  <th className="px-4 py-3 text-sm font-medium text-gray-600 dark:text-gray-300">Lucro</th>
                  <th className="px-4 py-3 text-sm font-medium text-gray-600 dark:text-gray-300">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                {bettingHistory.map((bet) => (
                  <tr key={bet.id} className="hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors">
                    <td className="px-4 py-3 text-sm text-gray-600 dark:text-gray-400">
                      {format(new Date(bet.date), 'dd/MM/yyyy')}
                    </td>
                    <td className="px-4 py-3 text-sm font-medium">{bet.event}</td>
                    <td className="px-4 py-3 text-sm text-gray-600 dark:text-gray-400">
                      {bet.bookmakers.map(b => b.name).join(', ')}
                    </td>
                    <td className={`px-4 py-3 text-sm font-medium ${bet.profit >= 0 ? 'text-success-600 dark:text-success-400' : 'text-error-600 dark:text-error-400'}`}>
                      R$ {bet.profit.toFixed(2)}
                    </td>
                    <td className="px-4 py-3 text-sm">
                      {bet.status === 'completed' && (
                        <span className="px-2 py-1 bg-success-100 dark:bg-success-900/30 text-success-800 dark:text-success-400 rounded-full text-xs">
                          Concluída
                        </span>
                      )}
                      {bet.status === 'pending' && (
                        <span className="px-2 py-1 bg-yellow-100 dark:bg-yellow-900/30 text-yellow-800 dark:text-yellow-400 rounded-full text-xs flex items-center">
                          <Clock size={12} className="mr-1" />
                          Pendente
                        </span>
                      )}
                      {bet.status === 'canceled' && (
                        <span className="px-2 py-1 bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-400 rounded-full text-xs">
                          Cancelada
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-6 text-center">
            <p className="text-gray-600 dark:text-gray-400">
              Você ainda não registrou nenhuma aposta.
            </p>
            <Link to="/surebets" className="btn-primary mt-4 inline-block">
              Encontrar Oportunidades
            </Link>
          </div>
        )}
      </div>
      
      {/* Placeholder for demo data */}
      {bettingHistory.length === 0 && (
        <div className="mt-8 p-4 border border-gray-200 dark:border-gray-700 rounded-lg">
          <h3 className="text-lg font-medium mb-2">Dados de demonstração</h3>
          <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
            Para demonstração, você pode adicionar alguns dados fictícios de apostas ao seu histórico.
          </p>
          <button
            onClick={() => {
              const demoRecords: BetRecord[] = [
                {
                  id: '1',
                  date: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
                  event: 'Flamengo vs Corinthians',
                  bookmakers: [
                    { name: 'Betano', stake: 500, odds: 2.1 },
                    { name: 'Bet365', stake: 500, odds: 2.15 }
                  ],
                  profit: 50,
                  status: 'completed'
                },
                {
                  id: '2',
                  date: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
                  event: 'Djokovic vs Nadal',
                  bookmakers: [
                    { name: 'Sportingbet', stake: 300, odds: 1.8 },
                    { name: 'Pixbet', stake: 350, odds: 1.95 }
                  ],
                  profit: 32.5,
                  status: 'completed'
                },
                {
                  id: '3',
                  date: new Date(),
                  event: 'Lakers vs Bulls',
                  bookmakers: [
                    { name: 'KTO', stake: 200, odds: 2.5 },
                    { name: 'Betano', stake: 230, odds: 2.3 }
                  ],
                  profit: 25,
                  status: 'pending'
                },
              ];
              
              demoRecords.forEach(record => {
                setTimeout(() => {
                  updateSettings({ bankroll: settings.bankroll + record.profit });
                }, 100);
              });
              
              // Add records one by one with a slight delay for better UX
              const addRecordsWithDelay = (records: BetRecord[], index = 0) => {
                if (index >= records.length) return;
                
                setTimeout(() => {
                  updateSettings({ bankroll: settings.bankroll + records[index].profit });
                }, 100);
              };
            }}
            className="btn-outline text-sm"
          >
            Adicionar Dados de Demonstração
          </button>
        </div>
      )}
    </div>
  );
};

export default Dashboard;