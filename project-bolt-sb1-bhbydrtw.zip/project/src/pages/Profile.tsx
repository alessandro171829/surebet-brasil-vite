import React, { useState } from 'react';
import { toast } from 'react-toastify';
import { User, Bell, LogOut } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useUser } from '../contexts/UserContext';
import { useNavigate } from 'react-router-dom';

const Profile: React.FC = () => {
  const { user, logout } = useAuth();
  const { settings, updateSettings } = useUser();
  const navigate = useNavigate();
  
  const [name, setName] = useState(user?.name || '');
  const [email, setEmail] = useState(user?.email || '');
  const [notificationsEnabled, setNotificationsEnabled] = useState(settings.notificationsEnabled);
  const [profitThreshold, setProfitThreshold] = useState(settings.profitThreshold);
  
  const handleSaveProfile = () => {
    toast.success('Perfil atualizado com sucesso');
  };
  
  const handleSavePreferences = () => {
    updateSettings({
      notificationsEnabled,
      profitThreshold
    });
    toast.success('Preferências atualizadas com sucesso');
  };
  
  const handleLogout = () => {
    logout();
    navigate('/');
  };
  
  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-2xl md:text-3xl font-bold mb-6">Perfil</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="card p-6 md:col-span-2">
          <div className="flex items-center mb-6">
            <div className="p-3 bg-primary-100 dark:bg-primary-900/30 rounded-lg mr-4">
              <User size={24} className="text-primary-600 dark:text-primary-400" />
            </div>
            <h2 className="text-xl font-semibold">Informações Pessoais</h2>
          </div>
          
          <form>
            <div className="mb-4">
              <label htmlFor="name" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Nome
              </label>
              <input
                type="text"
                id="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="input"
              />
            </div>
            
            <div className="mb-6">
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Email
              </label>
              <input
                type="email"
                id="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="input"
              />
            </div>
            
            <button
              type="button"
              onClick={handleSaveProfile}
              className="btn-primary"
            >
              Salvar Alterações
            </button>
          </form>
        </div>
        
        <div className="flex flex-col gap-6">
          <div className="card p-6">
            <div className="flex items-center mb-4">
              <span className={`w-3 h-3 rounded-full ${user?.isPremium ? 'bg-success-500' : 'bg-gray-400'} mr-2`}></span>
              <span className="font-medium">
                {user?.isPremium ? 'Premium' : 'Conta Gratuita'}
              </span>
            </div>
            
            {user?.isPremium ? (
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Você tem acesso a todas as funcionalidades premium do SureBrasil.
              </p>
            ) : (
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                  Faça o upgrade para o plano premium para acessar todas as funcionalidades.
                </p>
                <a href="/premium" className="btn-primary text-center block">
                  Obter Premium
                </a>
              </div>
            )}
          </div>
          
          <div className="card p-6">
            <div className="flex items-center mb-6">
              <div className="p-3 bg-primary-100 dark:bg-primary-900/30 rounded-lg mr-4">
                <Bell size={20} className="text-primary-600 dark:text-primary-400" />
              </div>
              <h2 className="text-lg font-semibold">Notificações</h2>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={notificationsEnabled}
                    onChange={() => setNotificationsEnabled(!notificationsEnabled)}
                    className="rounded border-gray-300 text-primary-600 focus:ring-primary-500 mr-2"
                  />
                  <span>Ativar notificações</span>
                </label>
                <p className="text-sm text-gray-500 dark:text-gray-400 mt-1 ml-6">
                  Receba alertas sobre novas oportunidades de arbitragem
                </p>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Notificar apenas surebets com lucro acima de
                </label>
                <div className="flex items-center">
                  <input
                    type="range"
                    min="1"
                    max="10"
                    step="0.5"
                    value={profitThreshold}
                    onChange={(e) => setProfitThreshold(parseFloat(e.target.value))}
                    className="w-full mr-2"
                  />
                  <span className="text-sm font-medium w-12">{profitThreshold}%</span>
                </div>
              </div>
              
              <button
                type="button"
                onClick={handleSavePreferences}
                className="btn-outline w-full text-sm"
              >
                Salvar Preferências
              </button>
            </div>
          </div>
          
          <button
            onClick={handleLogout}
            className="btn-outline text-error-600 hover:bg-error-50 dark:text-error-400 dark:hover:bg-error-900/20 flex items-center justify-center"
          >
            <LogOut size={16} className="mr-2" />
            <span>Sair da Conta</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default Profile;