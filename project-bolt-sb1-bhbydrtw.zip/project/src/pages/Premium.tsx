import React from 'react';
import { Link } from 'react-router-dom';
import { Check, AlertTriangle, CreditCard, Lock } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

const Premium: React.FC = () => {
  const { isAuthenticated, user } = useAuth();
  
  return (
    <div className="max-w-4xl mx-auto">
      <div className="text-center mb-12">
        <h1 className="text-3xl md:text-4xl font-bold mb-4">
          Acesso <span className="text-primary-600 dark:text-primary-400">Premium Vitalício</span>
        </h1>
        <p className="text-lg text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
          Desbloqueie o poder completo da arbitragem esportiva com acesso vitalício a todas as ferramentas e oportunidades.
        </p>
      </div>
      
      {user?.isPremium ? (
        <div className="bg-success-50 dark:bg-success-900/20 p-8 rounded-xl text-center mb-12">
          <div className="w-16 h-16 bg-success-100 dark:bg-success-800 text-success-600 dark:text-success-300 rounded-full flex items-center justify-center mx-auto mb-4">
            <Check size={32} strokeWidth={3} />
          </div>
          <h2 className="text-2xl font-bold text-success-700 dark:text-success-300 mb-3">
            Você já é um usuário Premium!
          </h2>
          <p className="text-success-600 dark:text-success-400 mb-6">
            Aproveite todos os benefícios do acesso vitalício ao SureBrasil.
          </p>
          <Link to="/surebets" className="btn-primary">
            Ver Oportunidades
          </Link>
        </div>
      ) : (
        <>
          {/* Premium Features */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
            <div className="card p-6">
              <div className="w-12 h-12 bg-primary-100 dark:bg-primary-900 text-primary-600 dark:text-primary-400 rounded-full flex items-center justify-center mb-4">
                <Check size={24} />
              </div>
              <h3 className="text-xl font-semibold mb-2">Acesso Ilimitado</h3>
              <p className="text-gray-600 dark:text-gray-400">
                Veja todas as surebets disponíveis sem restrições ou limites diários.
              </p>
            </div>
            
            <div className="card p-6">
              <div className="w-12 h-12 bg-primary-100 dark:bg-primary-900 text-primary-600 dark:text-primary-400 rounded-full flex items-center justify-center mb-4">
                <Check size={24} />
              </div>
              <h3 className="text-xl font-semibold mb-2">Alertas em Tempo Real</h3>
              <p className="text-gray-600 dark:text-gray-400">
                Receba notificações instantâneas sobre novas oportunidades de alto lucro.
              </p>
            </div>
            
            <div className="card p-6">
              <div className="w-12 h-12 bg-primary-100 dark:bg-primary-900 text-primary-600 dark:text-primary-400 rounded-full flex items-center justify-center mb-4">
                <Check size={24} />
              </div>
              <h3 className="text-xl font-semibold mb-2">Calculadora Avançada</h3>
              <p className="text-gray-600 dark:text-gray-400">
                Use nossa calculadora avançada para maximizar seus lucros em cada oportunidade.
              </p>
            </div>
          </div>
          
          {/* Pricing */}
          <div className="card p-8 border-primary-300 dark:border-primary-600 mb-12">
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
              <div>
                <div className="bg-primary-100 dark:bg-primary-900/60 text-primary-800 dark:text-primary-200 text-sm font-medium py-1 px-3 rounded-full inline-block mb-2">
                  Oferta por Tempo Limitado
                </div>
                <h2 className="text-2xl md:text-3xl font-bold mb-2">Premium Vitalício</h2>
                <p className="text-gray-600 dark:text-gray-300 mb-4">
                  Pague apenas uma vez e obtenha acesso vitalício a todas as funcionalidades.
                </p>
                
                <div className="flex items-center gap-4 mb-2">
                  <span className="text-3xl md:text-4xl font-bold">R$ 197</span>
                  <span className="text-lg line-through text-gray-500">R$ 497</span>
                  <span className="bg-success-100 dark:bg-success-900/30 text-success-800 dark:text-success-300 text-sm font-medium py-1 px-2 rounded">
                    60% OFF
                  </span>
                </div>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  Pagamento único, sem mensalidades.
                </p>
              </div>
              
              <div className="w-full md:w-auto">
                {isAuthenticated ? (
                  <button className="btn-primary w-full md:w-auto px-8 py-3 text-lg flex items-center justify-center">
                    <CreditCard size={20} className="mr-2" />
                    Adquirir Premium
                  </button>
                ) : (
                  <div className="w-full md:w-auto">
                    <Link to="/register" className="btn-primary w-full md:w-auto px-8 py-3 text-lg flex items-center justify-center">
                      <Lock size={20} className="mr-2" />
                      Cadastre-se para Comprar
                    </Link>
                    <p className="text-xs text-gray-500 dark:text-gray-400 mt-2 text-center">
                      Você precisa estar logado para concluir a compra
                    </p>
                  </div>
                )}
              </div>
            </div>
            
            <div className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-700">
              <h3 className="font-semibold mb-3">O que está incluso:</h3>
              <ul className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <li className="flex items-start">
                  <Check size={18} className="text-success-500 mr-2 mt-0.5 shrink-0" />
                  <span>Acesso vitalício sem mensalidades</span>
                </li>
                <li className="flex items-start">
                  <Check size={18} className="text-success-500 mr-2 mt-0.5 shrink-0" />
                  <span>Todas as surebets disponíveis sem limitações</span>
                </li>
                <li className="flex items-start">
                  <Check size={18} className="text-success-500 mr-2 mt-0.5 shrink-0" />
                  <span>Calculadora avançada de apostas</span>
                </li>
                <li className="flex items-start">
                  <Check size={18} className="text-success-500 mr-2 mt-0.5 shrink-0" />
                  <span>Notificações em tempo real</span>
                </li>
                <li className="flex items-start">
                  <Check size={18} className="text-success-500 mr-2 mt-0.5 shrink-0" />
                  <span>Dashboard avançado com estatísticas</span>
                </li>
                <li className="flex items-start">
                  <Check size={18} className="text-success-500 mr-2 mt-0.5 shrink-0" />
                  <span>Suporte prioritário</span>
                </li>
                <li className="flex items-start">
                  <Check size={18} className="text-success-500 mr-2 mt-0.5 shrink-0" />
                  <span>Atualizações futuras incluídas</span>
                </li>
                <li className="flex items-start">
                  <Check size={18} className="text-success-500 mr-2 mt-0.5 shrink-0" />
                  <span>7 dias de garantia de satisfação</span>
                </li>
              </ul>
            </div>
          </div>
          
          {/* Free vs Premium Comparison */}
          <div className="mb-12">
            <h2 className="text-2xl font-bold mb-6 text-center">Plano Gratuito vs Premium</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="card p-6">
                <h3 className="text-xl font-semibold mb-4">Plano Gratuito</h3>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <Check size={18} className="text-success-500 mr-2 mt-0.5 shrink-0" />
                    <span>2 surebets gratuitas</span>
                  </li>
                  <li className="flex items-start">
                    <Check size={18} className="text-success-500 mr-2 mt-0.5 shrink-0" />
                    <span>Calculadora básica</span>
                  </li>
                  <li className="flex items-start text-gray-500 line-through">
                    <AlertTriangle size={18} className="mr-2 mt-0.5 shrink-0" />
                    <span>Acesso ilimitado a surebets</span>
                  </li>
                  <li className="flex items-start text-gray-500 line-through">
                    <AlertTriangle size={18} className="mr-2 mt-0.5 shrink-0" />
                    <span>Notificações em tempo real</span>
                  </li>
                </ul>
              </div>
              
              <div className="card p-6 border-primary-300 dark:border-primary-600">
                <h3 className="text-xl font-semibold mb-4">Plano Premium</h3>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <Check size={18} className="text-success-500 mr-2 mt-0.5 shrink-0" />
                    <span>Acesso ilimitado a todas as surebets</span>
                  </li>
                  <li className="flex items-start">
                    <Check size={18} className="text-success-500 mr-2 mt-0.5 shrink-0" />
                    <span>Calculadora avançada</span>
                  </li>
                  <li className="flex items-start">
                    <Check size={18} className="text-success-500 mr-2 mt-0.5 shrink-0" />
                    <span>Notificações em tempo real</span>
                  </li>
                  <li className="flex items-start">
                    <Check size={18} className="text-success-500 mr-2 mt-0.5 shrink-0" />
                    <span>Dashboard e estatísticas</span>
                  </li>
                  <li className="flex items-start">
                    <Check size={18} className="text-success-500 mr-2 mt-0.5 shrink-0" />
                    <span>Suporte prioritário</span>
                  </li>
                  <li className="flex items-start">
                    <Check size={18} className="text-success-500 mr-2 mt-0.5 shrink-0" />
                    <span>Acesso vitalício</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          
          {/* Guarantees */}
          <div className="bg-gray-50 dark:bg-gray-800 p-6 rounded-lg">
            <div className="flex gap-4 items-start">
              
              <div className="bg-warning-100 dark:bg-warning-900/30 p-3 rounded-lg">
                <AlertTriangle size={24} className="text-warning-600 dark:text-warning-400" />
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-1">Importante: Aposte com responsabilidade</h3>
                <p className="text-gray-600 dark:text-gray-400">
                  Embora as surebets ofereçam oportunidades de lucro garantido quando feitas corretamente, é importante não apostar mais do que você pode perder e jogar sempre com responsabilidade.
                </p>
              </div>
            </div>
          </div>
        </>
      )}
      
      {/* FAQ */}
      <div className="mt-16">
        <h2 className="text-2xl font-bold mb-6 text-center">Perguntas Frequentes</h2>
        
        <div className="space-y-4">
          <div className="card p-6">
            <h3 className="text-lg font-semibold mb-2">O que são surebets?</h3>
            <p className="text-gray-600 dark:text-gray-400">
              Surebets (ou apostas de arbitragem) são oportunidades de apostas que garantem lucro independente do resultado do evento. Isso é possível apostando em todos os resultados possíveis em diferentes casas de apostas com odds que permitem lucro.
            </p>
          </div>
          
          <div className="card p-6">
            <h3 className="text-lg font-semibold mb-2">Como funciona o pagamento único vitalício?</h3>
            <p className="text-gray-600 dark:text-gray-400">
              Você paga apenas uma vez e obtém acesso permanente a todas as funcionalidades premium do SureBrasil, incluindo todas as atualizações futuras da plataforma, sem custos adicionais ou mensalidades.
            </p>
          </div>
          
          <div className="card p-6">
            <h3 className="text-lg font-semibold mb-2">Existe garantia de devolução do dinheiro?</h3>
            <p className="text-gray-600 dark:text-gray-400">
              Sim, oferecemos garantia de satisfação de 7 dias. Se você não ficar satisfeito com o serviço por qualquer motivo, entre em contato conosco e devolveremos seu dinheiro.
            </p>
          </div>
          
          <div className="card p-6">
            <h3 className="text-lg font-semibold mb-2">Quais casas de apostas são suportadas?</h3>
            <p className="text-gray-600 dark:text-gray-400">
              Nossa plataforma monitora todas as principais casas de apostas regulamentadas no Brasil, incluindo Betano, Bet365, Sportingbet, Pixbet, KTO, Galera.bet, Betsson, Parimatch, Pinnacle, Rivalo, Betway e 22Bet.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Premium;