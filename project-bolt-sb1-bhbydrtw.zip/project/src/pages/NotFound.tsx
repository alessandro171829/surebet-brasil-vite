import React from 'react';
import { Link } from 'react-router-dom';
import { Home } from 'lucide-react';

const NotFound: React.FC = () => {
  return (
    <div className="min-h-[60vh] flex flex-col items-center justify-center">
      <div className="text-9xl font-bold text-primary-200 dark:text-primary-900">404</div>
      <h1 className="text-3xl font-bold mt-4 mb-2">Página não encontrada</h1>
      <p className="text-gray-600 dark:text-gray-400 mb-8 text-center max-w-md">
        A página que você está procurando não existe ou foi movida.
      </p>
      <Link to="/" className="btn-primary flex items-center">
        <Home size={18} className="mr-2" />
        <span>Voltar para o Início</span>
      </Link>
    </div>
  );
};

export default NotFound;