import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Check, BarChart3, Calculator, Clock, Shield } from 'lucide-react';

const Home: React.FC = () => {
  return (
    <div className="flex flex-col space-y-20">
      {/* Hero Section */}
      <section className="py-12 md:py-20">
        <div className="max-w-5xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 dark:text-white mb-6">
            Apostas com <span className="text-primary-600 dark:text-primary-400">Lucro Garantido</span>
          </h1>
          <p className="text-xl md:text-2xl text-gray-600 dark:text-gray-300 mb-8 max-w-3xl mx-auto">
            O SureBrasil encontra oportunidades de arbitragem esportiva em tempo real entre as principais casas de apostas do Brasil.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/register" className="btn-primary text-base py-3 px-6">
              Começar Agora
              <ArrowRight size={18} className="ml-2 inline" />
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-12">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">Como o SureBrasil Funciona</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="card p-6 flex flex-col items-center text-center">
              <div className="w-12 h-12 bg-primary-100 dark:bg-primary-900 rounded-full flex items-center justify-center mb-4">
                <BarChart3 className="text-primary-600 dark:text-primary-400" size={24} />
              </div>
              <h3 className="text-xl font-semibold mb-2">Monitoramento em Tempo Real</h3>
              <p className="text-gray-600 dark:text-gray-300">
                Rastreamos continuamente as odds de todas as principais casas de apostas do Brasil.
              </p>
            </div>
            
            <div className="card p-6 flex flex-col items-center text-center">
              <div className="w-12 h-12 bg-primary-100 dark:bg-primary-900 rounded-full flex items-center justify-center mb-4">
                <Calculator className="text-primary-600 dark:text-primary-400" size={24} />
              </div>
              <h3 className="text-xl font-semibold mb-2">Cálculo Automático</h3>
              <p className="text-gray-600 dark:text-gray-300">
                Identificamos e calculamos automaticamente apostas com lucro garantido independente do resultado.
              </p>
            </div>
            
            <div className="card p-6 flex flex-col items-center text-center">
              <div className="w-12 h-12 bg-primary-100 dark:bg-primary-900 rounded-full flex items-center justify-center mb-4">
                <Clock className="text-primary-600 dark:text-primary-400" size={24} />
              </div>
              <h3 className="text-xl font-semibold mb-2">Alertas Instantâneos</h3>
              <p className="text-gray-600 dark:text-gray-300">
                Receba notificações imediatas quando encontramos oportunidades com alto potencial de lucro.
              </p>
            </div>
            
            <div className="card p-6 flex flex-col items-center text-center">
              <div className="w-12 h-12 bg-primary-100 dark:bg-primary-900 rounded-full flex items-center justify-center mb-4">
                <Shield className="text-primary-600 dark:text-primary-400" size={24} />
              </div>
              <h3 className="text-xl font-semibold mb-2">Risco Zero</h3>
              <p className="text-gray-600 dark:text-gray-300">
                Aplicando a estratégia corretamente, você obtém lucro independentemente do resultado do evento.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-primary-50 dark:bg-primary-900/20 rounded-3xl">
        <div className="max-w-5xl mx-auto px-6">
          <div className="text-center mb-10">
            <h2 className="text-3xl font-bold mb-4">Comece a Lucrar Hoje Mesmo</h2>
            <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
              Junte-se a milhares de apostadores que já estão aproveitando oportunidades de arbitragem para lucrar diariamente.
            </p>
          </div>
          
          <div className="card p-6 border-primary-300 dark:border-primary-600">
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
              <div>
                <div className="bg-primary-100 dark:bg-primary-900/60 text-primary-800 dark:text-primary-200 text-sm font-medium py-1 px-3 rounded-full inline-block mb-2">
                  Oferta por Tempo Limitado
                </div>
                <h2 className="text-2xl md:text-3xl font-bold mb-2">Premium Vitalício</h2>
                <p className="text-gray-600 dark:text-gray-300 mb-4">
                  Pague apenas uma vez e obtenha acesso vitalício a todas as funcionalidades.
                </p>
                
                <div className="flex items-center gap-4 mb-2">
                  <span className="text-3xl md:text-4xl font-bold">R$ 297</span>
                  <span className="text-lg line-through text-gray-500">R$ 497</span>
                  <span className="bg-success-100 dark:bg-success-900/30 text-success-800 dark:text-success-300 text-sm font-medium py-1 px-2 rounded">
                    40% OFF
                  </span>
                </div>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  Pagamento único, sem mensalidades
                </p>
              </div>
              
              <Link to="/register" className="btn-primary w-full md:w-auto px-8 py-3 text-lg">
                Garantir Minha Vaga
              </Link>
            </div>
            
            <div className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-700">
              <h3 className="font-semibold mb-3">O que está incluso:</h3>
              <ul className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <li className="flex items-start">
                  <Check size={18} className="text-success-500 mr-2 mt-0.5 shrink-0" />
                  <span>Acesso vitalício sem mensalidades</span>
                </li>
                <li className="flex items-start">
                  <Check size={18} className="text-success-500 mr-2 mt-0.5 shrink-0" />
                  <span>Todas as surebets disponíveis sem limitações</span>
                </li>
                <li className="flex items-start">
                  <Check size={18} className="text-success-500 mr-2 mt-0.5 shrink-0" />
                  <span>Calculadora avançada de apostas</span>
                </li>
                <li className="flex items-start">
                  <Check size={18} className="text-success-500 mr-2 mt-0.5 shrink-0" />
                  <span>Notificações em tempo real</span>
                </li>
                <li className="flex items-start">
                  <Check size={18} className="text-success-500 mr-2 mt-0.5 shrink-0" />
                  <span>Dashboard avançado com estatísticas</span>
                </li>
                <li className="flex items-start">
                  <Check size={18} className="text-success-500 mr-2 mt-0.5 shrink-0" />
                  <span>Suporte prioritário</span>
                </li>
                <li className="flex items-start">
                  <Check size={18} className="text-success-500 mr-2 mt-0.5 shrink-0" />
                  <span>Atualizações futuras incluídas</span>
                </li>
                <li className="flex items-start">
                  <Check size={18} className="text-success-500 mr-2 mt-0.5 shrink-0" />
                  <span>7 dias de garantia de satisfação</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-12">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">O Que Dizem Nossos Usuários</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="card p-6">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 rounded-full bg-gray-300 dark:bg-gray-600 flex items-center justify-center text-xl font-bold text-white">R</div>
                <div className="ml-3">
                  <h4 className="font-semibold">Roberto S.</h4>
                  <div className="text-sm text-gray-600 dark:text-gray-400">Usuário desde 2023</div>
                </div>
              </div>
              <p className="text-gray-600 dark:text-gray-300">
                "Com o SureBrasil consegui aumentar meu bankroll em 35% em apenas 2 meses. O sistema é muito simples de usar e as oportunidades são frequentes."
              </p>
            </div>
            
            <div className="card p-6">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 rounded-full bg-gray-300 dark:bg-gray-600 flex items-center justify-center text-xl font-bold text-white">M</div>
                <div className="ml-3">
                  <h4 className="font-semibold">Márcia T.</h4>
                  <div className="text-sm text-gray-600 dark:text-gray-400">Usuária desde 2024</div>
                </div>
              </div>
              <p className="text-gray-600 dark:text-gray-300">
                "Mesmo sem experiência em apostas, consegui obter lucros consistentes. A calculadora de stakes torna tudo muito fácil e as notificações não deixam passar nenhuma oportunidade."
              </p>
            </div>
            
            <div className="card p-6">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 rounded-full bg-gray-300 dark:bg-gray-600 flex items-center justify-center text-xl font-bold text-white">F</div>
                <div className="ml-3">
                  <h4 className="font-semibold">Felipe G.</h4>
                  <div className="text-sm text-gray-600 dark:text-gray-400">Usuário desde 2023</div>
                </div>
              </div>
              <p className="text-gray-600 dark:text-gray-300">
                "O acesso premium valeu cada centavo. Já recuperei o investimento nas primeiras semanas e agora estou lucrando cerca de R$1.500 por mês de forma consistente."
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-12 text-center">
        <h2 className="text-3xl font-bold mb-6">Pronto para Começar?</h2>
        <p className="text-xl text-gray-600 dark:text-gray-300 mb-8 max-w-3xl mx-auto">
          Não perca mais tempo com apostas arriscadas. Comece a fazer apostas com lucro garantido agora mesmo.
        </p>
        <Link to="/register" className="btn-primary text-base py-3 px-8">
          Garantir Minha Vaga
        </Link>
      </section>
    </div>
  );
};

export default Home;